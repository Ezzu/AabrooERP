<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class DonarPaymentsModel extends Model
{
    use SoftDeletes;

    protected $fillable = ['sponsership_id', 'payment_status', 'payment_date', 'created_at', 'updated_at', 'created_by', 'updated_by', 'deleted_by', 'deleted_at'];

    protected $table = "donar_payments";

    public function student_sponsership(){
        return $this->belongsTo('App\Models\Admin\StudentsDonarsModel', 'sponsership_id');
    }

    static function getActiveOnly(){
        return self::all();
    }

    static public function pluckActiveOnly(){
        return self::where(['deleted_at' => NULL])->pluck('name','id');
    }

}
