<?php echo e(csrf_field()); ?>


<div class="<?php echo e($errors->has('employee_id') ? 'text-danger' : ''); ?> form-group col-md-3" id="employee_id_div">
    <?php echo Form::label('employee_id', 'Employee *', ['class' => 'control-label', 'style' => ""]); ?>

    <?php echo Form::select('employee_id', $Employees, old('employee_id'), ['class' => 'form-control select2']); ?>

    <?php if($errors->has('employee_id')): ?>
        <div class="text-danger"><?php echo e($errors->first('employee_id')); ?></div>
    <?php endif; ?>
</div>

<div class="<?php echo e($errors->has('emergency_contact') ? 'text-danger' : ''); ?> form-group col-md-3" id="emergency_contact_div">
    <?php echo Form::label('emergency_contact', 'Emergency Contact *', ['class' => 'control-label', 'style' => ""]); ?>

    <?php echo Form::number('emergency_contact', old('emergency_contact'), ['class' => 'form-control']); ?>

    <?php if($errors->has('emergency_contact')): ?>
        <div class="text-danger"><?php echo e($errors->first('emergency_contact')); ?></div>
    <?php endif; ?>
</div>

<div class="<?php echo e($errors->has('area_id') ? 'text-danger' : ''); ?> form-group col-md-3" id="area_id_div">
    <?php echo Form::label('area_id', 'Area *', ['class' => 'control-label', 'style' => ""]); ?>

    <?php echo Form::select('area_id[]', $Areas, old('area_id'), ['class' => 'form-control select2', 'multiple' => 'true']); ?>

    <?php if($errors->has('area_id')): ?>
        <div class="text-danger"><?php echo e($errors->first('area_id')); ?></div>
    <?php endif; ?>
</div>

<div class="<?php echo e($errors->has('day_id') ? 'text-danger' : ''); ?> form-group col-md-3" id="day_id_div">
    <?php echo Form::label('day_id', 'Day *', ['class' => 'control-label', 'style' => ""]); ?>

    <?php echo Form::select('day_id', $Days, old('day_id'), ['class' => 'form-control']); ?>

    <?php if($errors->has('day_id')): ?>
        <div class="text-danger"><?php echo e($errors->first('day_id')); ?></div>
    <?php endif; ?>
</div>