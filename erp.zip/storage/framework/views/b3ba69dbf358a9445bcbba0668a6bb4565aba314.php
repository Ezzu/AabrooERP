<?php echo e(csrf_field()); ?>


<div class="<?php echo e($errors->has('name') ? 'text-danger' : ''); ?> form-group col-md-3" id="name_div">
    <?php echo Form::label('name', 'Department Name *', ['class' => 'control-label', 'style' => ""]); ?>

    <?php echo Form::text('name', old('name') ,['class' => 'form-control']); ?>

    <?php if($errors->has('name')): ?>
        <div class="text-danger"><?php echo e($errors->first('name')); ?></div>
    <?php endif; ?>
</div>