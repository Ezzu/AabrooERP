<?php echo e(csrf_field()); ?>


<div class="<?php echo e($errors->has('name') ? 'text-danger' : ''); ?> form-group col-md-3" id="name_div">
    <?php echo Form::label('name', 'Branch Name *', ['class' => 'control-label', 'style' => ""]); ?>

    <?php echo Form::text('name', old('name') ,['class' => 'form-control']); ?>

    <?php if($errors->has('name')): ?>
        <div class="text-danger"><?php echo e($errors->first('name')); ?></div>
    <?php endif; ?>
</div>

<div class="<?php echo e($errors->has('contact') ? 'text-danger' : ''); ?> form-group col-md-3" id="contact_div">
    <?php echo Form::label('contact', 'Contact *', ['class' => 'control-label', 'style' => ""]); ?>

    <?php echo Form::number('contact', old('contact') ,['class' => 'form-control']); ?>

    <?php if($errors->has('contact')): ?>
        <div class="text-danger"><?php echo e($errors->first('contact')); ?></div>
    <?php endif; ?>
</div>

<div class="<?php echo e($errors->has('location') ? 'text-danger' : ''); ?> form-group col-md-3" id="location_div">
    <?php echo Form::label('location', 'Location *', ['class' => 'control-label', 'style' => ""]); ?>

    <?php echo Form::text('location', old('location') ,['class' => 'form-control']); ?>

    <?php if($errors->has('location')): ?>
        <div class="text-danger"><?php echo e($errors->first('location')); ?></div>
    <?php endif; ?>
</div>