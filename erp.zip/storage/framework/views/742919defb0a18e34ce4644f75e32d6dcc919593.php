<?php echo e(csrf_field()); ?>


<div class="<?php echo e($errors->has('donar_id') ? 'text-danger' : ''); ?> form-group col-md-3" id="donar_div">
    <?php echo Form::label('donar_id', 'Select a Donar *', ['class' => 'control-label', 'style' => ""]); ?>

    <?php echo Form::select('donar_id', $Donars, old('donar_id'), ['class' => 'form-control select2']); ?>

    <?php if($errors->has('donar_id')): ?>
        <div class="text-danger"><?php echo e($errors->first('donar_id')); ?></div>
    <?php endif; ?>
</div>  

<div class="<?php echo e($errors->has('student_id') ? 'text-danger' : ''); ?> form-group col-md-6" id="student_div">
    <?php echo Form::label('student_id', 'Select Student(s) *', ['class' => 'control-label', 'style' => ""]); ?>

    <?php echo Form::select('student_id[]', $Students, old('student_id'), ['class' => 'form-control select2', 'multiple' => 'multiple']); ?>

    <?php if($errors->has('student_id')): ?>
        <div class="text-danger"><?php echo e($errors->first('student_id')); ?></div>
    <?php endif; ?>
</div>  

<div class="<?php echo e($errors->has('sponser_type') ? 'text-danger' : ''); ?> form-group col-md-3" id="student_div">
    <?php echo Form::label('sponser_type', 'Sponser Type *', ['class' => 'control-label', 'style' => ""]); ?>

    <?php echo Form::select('sponser_type', array('' => 'Select a Type') + config('admin.sponser_type_array'), old('sponser_type'), ['class' => 'form-control select2',]); ?>

    <?php if($errors->has('sponser_type')): ?>
        <div class="text-danger"><?php echo e($errors->first('sponser_type')); ?></div>
    <?php endif; ?>
</div>