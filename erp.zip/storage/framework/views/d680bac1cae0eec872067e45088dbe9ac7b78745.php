<?php $__env->startSection('title', 'Aabroo Accounts'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 style="margin-bottom: 15px;">Branches</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="box box-primary">
        <div class="box-header">
            <h3 class="box-title" style="padding-top: 6px;">Create New Branch</h3>
            <a class="btn btn-success pull-right" href="<?php echo e(route('admin.donars.index')); ?>">Back</a>
        </div>
        <?php echo Form::model($Branch, ['method' => 'PUT', 'route' => ['admin.branches.update', $Branch->id]]); ?>

            <div class="box-body table-responsive">
                <?php echo $__env->make('admin.branches.fields', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <div class="box-footer">
                <button class="btn btn-danger"> Save </button>
            </div>
        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        var FormControls = function(){
            $('.select2').select2();
            $( ".datetimepicker" ).datepicker({
                format: "mm-dd-yyyy",
                weekStart: 0,
                calendarWeeks: true,
                autoclose: true,
                todayHighlight: true,
                rtl: true,
                orientation: "auto"
            });

        }();

        $(document).ready(function(){
            
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>