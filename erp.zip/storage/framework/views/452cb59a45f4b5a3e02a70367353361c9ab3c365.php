<?php $__env->startSection('title', 'Aabroo Accounts'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 style="margin-bottom: 15px;">Donars</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="box box-primary">
        <div class="box-header">
            <i class="fa fa-list" style="padding-top: 6px;" aria-hidden="true"></i>
            <h3 class="box-title" style="padding-top: 6px;">List</h3>
            <a class="btn btn-success pull-right" href="<?php echo e(route('admin.donars.create')); ?>">Add New Donar</a>
        </div>
        <div class="panel-body table-responsive">
            <table class="table-stripped table table-bordered" id="users-table">
                <thead>
                    <tr>
                        <th>ID</td>
                        <th>Donar Name</th>
                        <th>Sponsership Date</th>
                        <th>Contact</th>
                        <th># of Sponsers</th>
                        <th>Fee/Child</th>
                        <th>Payment Method</th>
                        <th>Created At</th>
                        <th>Modified At</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $Donars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Donar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($Donar->id); ?></td>
                            <td><?php echo e($Donar->donar_name); ?></td>
                            <td><?php echo e(date('F d, Y', strtotime($Donar->sponsership_date))); ?></td>
                            <td><?php echo e($Donar->phone_no); ?></td>
                            <td><?php echo e(\App\Models\Admin\StudentsDonarsModel::getSponserCountByDonarId($Donar->id)); ?></td>
                            <td><?php echo e($Donar->fee_per_child); ?></td>
                            <td><?php echo e(\App\Models\Admin\PaymentTypesModel::getPaymentTypeByID($Donar->payment_type_id)); ?></td>
                            <td><?php echo e($Donar->created_at); ?></td>
                            <td><?php echo e($Donar->updated_at); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.donars.edit', ['id' => $Donar->id])); ?>" class='btn btn-xs btn-info'><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit</a>
                                <form action="<?php echo e(route('admin.donars.destroy', ['id' => $Donar->id])); ?>">
                                    <?php echo e(method_field('DELETE')); ?>

                                    <?php echo e(csrf_field()); ?>

                                    <button class='btn btn-danger btn-xs' style='margin-top: 3px;' onclick='confirm("Are you sure you want to perform this action ?"'><i class="fa fa-trash" aria-hidden="true"></i> Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="javascript/text" src="<?php echo e(asset('js\admin\areas\list.js')); ?>"></script>
    <script>
        var FormControls = function(){
            $('#users-table').DataTable();

        }();

        $(document).ready(function(){

        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>