<?php echo e(csrf_field()); ?>


<div class="<?php echo e($errors->has('donar_name') ? 'text-danger' : ''); ?> form-group col-md-3" id="donar_name_div">
    <?php echo Form::label('donar_name', 'Donar Name *', ['class' => 'control-label', 'style' => ""]); ?>

    <?php echo Form::text('donar_name', old('donar_name'), ['class' => 'form-control']); ?>

    <?php if($errors->has('donar_name')): ?>
        <div class="text-danger"><?php echo e($errors->first('donar_name')); ?></div>
    <?php endif; ?>
</div>

<div class="<?php echo e($errors->has('address') ? 'text-danger' : ''); ?> form-group col-md-6" id="address_div">
    <?php echo Form::label('address', 'Address *', ['class' => 'control-label', 'style' => ""]); ?>

    <?php echo Form::text('address', old('address'), ['class' => 'form-control']); ?>

    <?php if($errors->has('address')): ?>
        <div class="text-danger"><?php echo e($errors->first('address')); ?></div>
    <?php endif; ?>
</div>

<div class="<?php echo e($errors->has('cnic') ? 'text-danger' : ''); ?> form-group col-md-3" id="cnic_div">
    <?php echo Form::label('cnic', 'CNIC', ['class' => 'control-label', 'style' => ""]); ?>

    <?php echo Form::text('cnic', old('cnic'), ['class' => 'form-control']); ?>

    <?php if($errors->has('cnic')): ?>
        <div class="text-danger"><?php echo e($errors->first('cnic')); ?></div>
    <?php endif; ?>
</div>

<div class="<?php echo e($errors->has('area_id') ? 'text-danger' : ''); ?> form-group col-md-3" id="area_id_div">
    <?php echo Form::label('area_id', 'Area *', ['class' => 'control-label', 'style' => ""]); ?>

    <?php echo Form::select('area_id', $Areas, old('area_id'), ['class' => 'form-control select2']); ?>

    <?php if($errors->has('area_id')): ?>
        <div class="text-danger"><?php echo e($errors->first('area_id')); ?></div>
    <?php endif; ?>
</div>

<div class="<?php echo e($errors->has('phone_no') ? 'text-danger' : ''); ?> form-group col-md-3" id="phone_no_div">
    <?php echo Form::label('phone_no', 'Phone No *', ['class' => 'control-label', 'style' => ""]); ?>

    <?php echo Form::text('phone_no', old('phone_no'), ['class' => 'form-control']); ?>

    <?php if($errors->has('phone_no')): ?>
        <div class="text-danger"><?php echo e($errors->first('phone_no')); ?></div>
    <?php endif; ?>
</div>

<div class="<?php echo e($errors->has('cell_no') ? 'text-danger' : ''); ?> form-group col-md-3" id="cell_no_div">
    <?php echo Form::label('cell_no', 'Cell No', ['class' => 'control-label', 'style' => ""]); ?>

    <?php echo Form::text('cell_no', old('cell_no'), ['class' => 'form-control']); ?>

    <?php if($errors->has('cell_no')): ?>
        <div class="text-danger"><?php echo e($errors->first('cell_no')); ?></div>
    <?php endif; ?>
</div>