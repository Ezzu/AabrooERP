<?php $__env->startSection('title', 'Aabroo Accounts'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 style="margin-bottom: 15px;">SW Employees</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="box box-primary">
        <div class="box-header">
            <i class="fa fa-list" style="padding-top: 6px;" aria-hidden="true"></i>
            <h3 class="box-title" style="padding-top: 6px;">List</h3>
            <a class="btn btn-success pull-right" href="<?php echo e(route('admin.swemployees.create')); ?>">Add New SW Employee</a>
        </div>
        <div class="panel-body table-responsive">
            <table class="table-stripped table table-bordered" id="users-table">
                <thead>
                    <tr>
                        <th>ID</td>
                        <th>Employee Name</th>
                        <th>Contact</th>
                        <th>Area(s)</th>
                        <th>Day</th>
                        <th>Created At</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $SWEmployees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($Employee->id); ?></td>
                            <td><?php echo e(App\Models\Admin\EmployeesModel::getEmployeeNameById($Employee->employee_id)); ?></td>
                            <td><?php echo e($Employee->emergency_contact); ?></td>
                            <td>
                                <?php if($Employee->areas): ?>
                                    <ol>
                                        <?php $__currentLoopData = $Employee->areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee_area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($employee_area->name); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ol>
                                <?php else: ?>
                                    'Not Specified'
                                <?php endif; ?>
                            </td>
                            <td><?php echo e(isset($Employee->working_day->name) ? $Employee->working_day->name : 'Not Specified'); ?></td>
                            <td><?php echo e($Employee->created_at); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.swemployees.edit', ['id' => $Employee->id])); ?>" class='btn btn-xs btn-info'><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit</a>
                                <form action="<?php echo e(route('admin.swemployees.destroy', ['id' => $Employee->id])); ?>" method="post">
                                    <?php echo e(method_field('DELETE')); ?>

                                    <?php echo e(csrf_field()); ?>

                                    <button class='btn btn-danger btn-xs' style='margin-top: 3px;' onclick='confirm("Are you sure you want to perform this action ?"'><i class="fa fa-trash" aria-hidden="true"></i> Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="javascript/text" src="<?php echo e(asset('js\admin\swemployees\list.js')); ?>"></script>
    <script>
        var FormControls = function(){
            $('#users-table').DataTable();

        }();

        $(document).ready(function(){

        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>