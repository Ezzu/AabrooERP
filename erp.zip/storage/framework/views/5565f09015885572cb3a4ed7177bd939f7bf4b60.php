<?php $__env->startSection('title', 'Aabroo Accounts'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 style="margin-bottom: 15px;">Employees</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="box box-primary">
        <div class="box-header">
            <h3 class="box-title" style="padding-top: 6px;">Update Employee</h3>
            <a class="btn btn-success pull-right" href="<?php echo e(route('admin.employees.index')); ?>">Back</a>
        </div>
        <?php echo Form::Model($Employee, ['route' => ['admin.employees.update', $Employee->id], 'method' => 'PUT', 'enctype' => 'multipart/form-data', 'id' => 'employees-form']); ?>

            <div class="box-body table-responsive">
                
                <?php echo $__env->make('admin.employees.fields', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                
            </div>
            <div class="box-footer">
                <button class="btn btn-danger" type="submit" onclick="document.getElementById('employees-form').submit();"> Save </button>
            </div>
        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript" src="<?php echo e(asset('js\admin\employees\create_modify.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>