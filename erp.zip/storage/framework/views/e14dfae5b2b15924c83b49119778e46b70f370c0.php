<?php $request = app('Illuminate\Http\Request'); ?>


<?php $__env->startSection('title', 'Aabroo Accounts'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 style="margin-bottom: 15px;">Donar Payments</h1>
    <?php echo Form::open(['method' => 'POST', 'route' => 'admin.donar_payments.index', 'id' => 'validation-form']); ?>

        <?php echo e(csrf_field()); ?>


        <div class="form-group col-md-3 <?php if($errors->has('month')): ?> has-error <?php endif; ?>" id="month_div">
            <?php echo Form::label('payment_status', 'Payment Status *', ['class' => 'control-label']); ?>

            <?php echo Form::select('payment_status', array('' => 'Choose a Status') + Config::get('admin.payment_status_array') , old('month'),
            ['class' => 'form-control select2'  ,'id' => 'payment_status']); ?>

        </div>

        <button id="search_button" style="margin-top: 25px;" class="btn  btn-sm btn-flat btn-primary"><b>&nbsp;Search </b> </button>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="box box-primary">
            <?php if(count($DonarPayments)): ?>
                        <div class="box-header">
                        <i class="fa fa-money" aria-hidden="true"></i> <h3 class="box-title">Donar Payments</h3>
                        <a class="btn btn-success pull-right" href="<?php echo e(route('admin.departments.create')); ?>"><i class="fa fa-refresh" aria-hidden="true"></i> Refresh</a>
                        </div>
                        <!-- /.box-header -->
                        <div class="panel-body pad table-responsive">
                            <table class="table table-striped" id="users-table">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Donar - Student</th>
                                        <th>Class</th>
                                        <th>Roll#</th>
                                        <th>Payment Type</th>
                                        <th>Payment Status</th>
                                        <th>Created At</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $DonarPayments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($payment->id); ?></td>
                                            <td><?php echo e($payment->student_sponsership->donar->donar_name); ?> - <?php echo e($payment->student_sponsership->student->name); ?></td>
                                            <td><?php echo e(config::get('admin.class_array.'.$payment->student_sponsership->student->class)); ?></td>
                                            <td><?php echo e($payment->student_sponsership->student->roll_no); ?></td>
                                            <td><?php echo e(config::get('admin.sponser_type_array.'.$payment->student_sponsership->donar->payment_type_id)); ?></td>
                                            <td><?php echo e(config::get('admin.payment_status_array.'.$payment->payment_status)); ?></td>
                                            <td><?php echo e($payment->created_at); ?></td>
                                            <td></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
            <?php else: ?>
                <div class="box-header text-center">
                    No Record Found
                </div>
            <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo $__env->make('partials.datatablesextensions', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script type="javascript/text" src="<?php echo e(asset('js\admin\donarpayments\list.js')); ?>"></script>
    <script>
        $('.select2').select2();
        $('#users-table').DataTable();
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>