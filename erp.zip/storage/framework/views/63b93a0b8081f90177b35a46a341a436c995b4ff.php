<?php $request = app('Illuminate\Http\Request'); ?>


<?php $__env->startSection('title', 'Aabroo Accounts'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 style="margin-bottom: 15px;">SW Management Report</h1>
    <?php echo Form::open(['method' => 'POST', 'route' => ['admin.swreport.search'], 'id' => 'validation-form']); ?>

        <?php echo e(csrf_field()); ?>


        <div class="form-group col-md-3 <?php if($errors->has('month')): ?> has-error <?php endif; ?>" id="month_div">
            <?php echo Form::label('month', 'Month *', ['class' => 'control-label']); ?>

            <?php echo Form::select('month', array('' => 'Choose a Month') + Config::get('admin.month_array') , old('month'),
            ['class' => 'form-control select2'  ,'id' => 'month']); ?>

        </div>

        <div class="form-group col-md-3 <?php if($errors->has('year')): ?> has-error <?php endif; ?>" id="year_div">
            <?php echo Form::label('year', 'Year *', ['class' => 'control-label']); ?>

            <?php echo Form::select('year', array('' => 'Choose an Year') + Config::get('admin.year_array') , old('year'),
            ['class' => 'form-control select2'  ,'id' => 'year']); ?>

        </div>

        <div class="form-group col-md-3 <?php if($errors->has('employee_id')): ?> has-error <?php endif; ?>" id="employee_id_div">
            <?php echo Form::label('employee_id', 'Employee *', ['class' => 'control-label']); ?>

            <?php echo Form::select('employee_id', $Employees, old('employee_id'),
            ['class' => 'form-control select2'  ,'id' => 'employee_id']); ?>

        </div>

        <button id="search_button" style="margin-top: 25px;" class="btn  btn-sm btn-flat btn-primary"><b>&nbsp;Search </b> </button>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<style>
.DTFC_LeftBodyLiner{
    top: -13px !important;
}
</style>
    <div class="clear-fix"></div>

    <div class="box box-primary">
            <?php if(isset($Reports) && $Reports): ?>
                        <div class="box-header">
                            <i class="fa fa-user"></i> <h3 class="box-title">SW Management Report</h3>
                        </div>
                        <!-- /.box-header -->
                        <div class="panel-body pad table-responsive">
                            <table class="table table-striped" id="tablewithextensions" >
                                <thead>
                                    <tr>
                                        <th style='background: #666; color: white;'>Employee : <?php echo e($Reports['employee']->name); ?></th>
                                        <th>Day : <?php echo e($Reports['day']); ?></th>
                                        <th>Month : <?php echo e(Config::get('admin.month_array.'.$Reports['month'])); ?></th>
                                        <?php for($i=0; $i<=count($Reports['dates']) + 1; $i++): ?>
                                            <td>&nbsp;</td>
                                        <?php endfor; ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th style='background: #666; color: white;'><?php echo e(Config::get('admin.month_array.'.$Reports['month'])); ?> <?php echo e($Reports['year']); ?></th>
                                        <th>Donar Name</th>
                                        <th>Address</th>
                                        <th>Contact</th>
                                        <th>Remarks</th>
                                        <?php $__currentLoopData = $Reports['dates']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date_day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                           
                                           <th><?php echo e($date_day[0]); ?></th>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                    <?php $count=0; ?>
                                    <?php $__currentLoopData = array_keys($Reports['donars']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td style='background: #666; color: white;'><?php echo e($area); ?></td>
                                            <?php for($i=0; $i<=count($Reports['dates'])+3; $i++): ?>
                                                <td>&nbsp;</td>
                                            <?php endfor; ?>
                                        </tr>
                                        <?php if($Reports['donars'][$area]): ?>
                                            <?php $__currentLoopData = $Reports['donars'][$area]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e(strval(++$count)); ?></td>
                                                    <td><?php echo e($donar->donar_name); ?></td>
                                                    <td><?php echo e($donar->address); ?></td>
                                                    <td><?php if($donar->phone_no): ?> <?php echo e(strval($donar->phone_no)); ?> <?php else: ?> <?php echo e(strval($donar->cell_no)); ?> <?php endif; ?></td>
                                                    <?php for($i=0; $i<=count($Reports['dates']); $i++): ?>
                                                        <td>&nbsp;</td>
                                                    <?php endfor; ?>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
            <?php else: ?>
                <div class="box-header text-center">
                    No Record Found
                </div>
            <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo $__env->make('partials.datatablesextensions', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script type="javascript/text" src="<?php echo e(asset('js\admin\swreports\list.js')); ?>"></script>
    <script>
        $('.select2').select2();
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>