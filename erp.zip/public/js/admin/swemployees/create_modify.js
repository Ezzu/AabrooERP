
var FormControls = function(){

    $('.select2').select2();

    var baseFunction = function(){

    }

}();

$(document).ready(function(){
    FormControls.init();
});