@inject('request', 'Illuminate\Http\Request')
@extends('adminlte::page')

@section('title', 'Aabroo Accounts')

@section('content_header')
    <h1 style="margin-bottom: 15px;">Donar Payments</h1>
    {!! Form::open(['method' => 'POST', 'route' => 'admin.donar_payments.index', 'id' => 'validation-form']) !!}
        {{csrf_field()}}

        <div class="form-group col-md-3 @if($errors->has('month')) has-error @endif" id="month_div">
            {!! Form::label('payment_status', 'Payment Status *', ['class' => 'control-label']) !!}
            {!! Form::select('payment_status', array('' => 'Choose a Status') + Config::get('admin.payment_status_array') , old('month'),
            ['class' => 'form-control select2'  ,'id' => 'payment_status']) !!}
        </div>

        <button id="search_button" style="margin-top: 25px;" class="btn  btn-sm btn-flat btn-primary"><b>&nbsp;Search </b> </button>
    {!! Form::close() !!}
@stop

@section('content')
    <div class="box box-primary">
            @if(count($DonarPayments))
                        <div class="box-header">
                        <i class="fa fa-money" aria-hidden="true"></i> <h3 class="box-title">Donar Payments</h3>
                        <a class="btn btn-success pull-right" href="{{ route('admin.departments.create') }}"><i class="fa fa-refresh" aria-hidden="true"></i> Refresh</a>
                        </div>
                        <!-- /.box-header -->
                        <div class="panel-body pad table-responsive">
                            <table class="table table-striped" id="users-table">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Donar - Student</th>
                                        <th>Class</th>
                                        <th>Roll#</th>
                                        <th>Payment Type</th>
                                        <th>Payment Status</th>
                                        <th>Created At</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($DonarPayments as $payment)
                                        <tr>
                                            <td>{{ $payment->id }}</td>
                                            <td>{{ $payment->student_sponsership->donar->donar_name }} - {{ $payment->student_sponsership->student->name }}</td>
                                            <td>{{ config::get('admin.class_array.'.$payment->student_sponsership->student->class) }}</td>
                                            <td>{{ $payment->student_sponsership->student->roll_no }}</td>
                                            <td>{{ config::get('admin.sponser_type_array.'.$payment->student_sponsership->donar->payment_type_id) }}</td>
                                            <td>{{ config::get('admin.payment_status_array.'.$payment->payment_status) }}</td>
                                            <td>{{ $payment->created_at }}</td>
                                            <td></td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
            @else
                <div class="box-header text-center">
                    No Record Found
                </div>
            @endif
    </div>
@stop

@section('js')
    @include('partials.datatablesextensions')
    <script type="javascript/text" src="{{ asset('js\admin\donarpayments\list.js') }}"></script>
    <script>
        $('.select2').select2();
        $('#users-table').DataTable();
    </script>
@endsection