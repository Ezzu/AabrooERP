<?php $__env->startSection('title', 'Aabroo Accounts'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 style="margin-bottom: 15px;">Payment Methods</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="box box-primary">
        <div class="box-header">
            <h3 class="box-title" style="padding-top: 6px;">Edit Payment Method</h3>
            <a class="btn btn-success pull-right" href="<?php echo e(route('admin.payment_types.index')); ?>">Back</a>
        </div>
        <?php echo Form::model($PaymentType, ['method' => 'PUT', 'route' => ['admin.payment_types.update', $PaymentType->id]]); ?>

            <div class="box-body table-responsive">
                <?php echo $__env->make('admin.paymenttypes.fields', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <div class="box-footer">
                <button class="btn btn-danger"> Save </button>
            </div>
        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $('#users-table').DataTable();
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>