<?php $__env->startSection('title', 'Aabroo Accounts'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 style="margin-bottom: 15px;">Areas</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="box box-primary">
        <div class="box-header">
            <h3 class="box-title" style="padding-top: 6px;">Create New Area</h3>
            <a class="btn btn-success pull-right" href="<?php echo e(route('admin.areas.index')); ?>">Back</a>
        </div>
        <?php echo Form::open(['route' => 'admin.donars_class.store']); ?>

            <div class="box-body table-responsive">
                <?php echo $__env->make('admin.donarsclass.fields', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <div class="box-footer">
                <button class="btn btn-danger"> Save </button>
            </div>
        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $('#users-table').DataTable();
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>