<?php $__env->startSection('title', 'Aabroo Accounts'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 style="margin-bottom: 15px;">Students</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="box box-primary">
        <div class="box-header">
            <i class="fa fa-list" style="padding-top: 6px;" aria-hidden="true"></i>
            <h3 class="box-title" style="padding-top: 6px;">List</h3>
            <a class="btn btn-success pull-right" href="<?php echo e(route('admin.students.create')); ?>">Add New Student</a>
        </div>
        <div class="panel-body table-responsive">
            <table class="table-stripped table table-bordered <?php echo e(count($Students) ? 'datatables' : ''); ?>" id="users-table">
                <thead>
                    <tr>
                        <th>ID</td>
                        <th>Student Name</th>
                        <th>Father Name</th>
                        <th>Age</th>
                        <th>Class</th>
                        <th>Shift</th>
                        <th>Admission Date</th>
                        <th>Contact</th>
                        <th>Address</th>
                        <th>Created At</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $Students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($Student->id); ?></td>
                        <td><?php echo e($Student->name); ?></td>
                        <td><?php echo e($Student->father_name); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($Student->date_of_birth)->diff(\Carbon\Carbon::now())->format('%y Years')); ?></td>
                        <td><?php echo e(Config::get('admin.class_array.'.$Student->class)); ?></td>
                        <td><?php echo e(Config::get('admin.shift_array.'.$Student->shift)); ?></td>
                        <td><?php echo e(date('F d, Y', strtotime($Student->admission_date))); ?></td>
                        <td><?php echo e($Student->cell_no); ?></td>
                        <td><?php echo e($Student->permanent_address); ?></td>
                        <td><?php echo e($Student->created_at); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.students.print', ['id' => $Student->id])); ?>" target='_blank' class='btn btn-xs btn-primary'><i class="fa fa-print" aria-hidden="true"></i> Print</a>
                            <a href="<?php echo e(route('admin.students.edit', ['id' => $Student->id])); ?>" class='btn btn-xs btn-info' style='margin-top: 3px;'><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit</a>
                            <form action="<?php echo e(route('admin.students.destroy', ['id' => $Student->id])); ?>">
                                <?php echo e(method_field('DELETE')); ?>

                                <?php echo e(csrf_field()); ?>

                                <button class='btn btn-danger btn-xs' style='margin-top: 3px;' onclick='confirm("Are you sure you want to perform this action ?"'><i class="fa fa-trash" aria-hidden="true"></i> Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="javascript/text" src="<?php echo e(asset('js\admin\students\list.js')); ?>"></script>
    <script>
        $('.datatables').DataTable({
            // processing: true,
            // serverSide: true,
            // ajax:{
            //     type: 'POST',
            //     url: '',
            //     data: {

            //     }
            // },
            // columns: {
            //     {}
            // }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>