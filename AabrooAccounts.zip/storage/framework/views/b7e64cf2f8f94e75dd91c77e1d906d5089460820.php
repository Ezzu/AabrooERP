<div class="panel-group">
  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" href="#collapse5">Guarantor Information</a>
      </h4>
    </div>
    <div id="collapse5" class="panel-collapse collapse">
      <div class="panel-body">
      
        <div class="<?php echo e($errors->has('guarantor_name') ? 'text-danger' : ''); ?> form-group col-md-3" id="guarantor_name_div">
            <?php echo Form::label('guarantor_name', 'Name', ['class' => 'control-label', 'style' => ""]); ?>

            <?php echo Form::text('guarantor_name', old('guarantor_name') ,['class' => 'form-control']); ?>

            <?php if($errors->has('guarantor_name')): ?>
                <div class="text-danger"><?php echo e($errors->first('guarantor_name')); ?></div>
            <?php endif; ?>
        </div>
        <div class="<?php echo e($errors->has('guarantor_relation') ? 'text-danger' : ''); ?> form-group col-md-3" id="guarantor_relation_div">
            <?php echo Form::label('guarantor_relation', 'Relation', ['class' => 'control-label', 'style' => ""]); ?>

            <?php echo Form::text('guarantor_relation', old('guarantor_relation') ,['class' => 'form-control']); ?>

            <?php if($errors->has('guarantor_relation')): ?>
                <div class="text-danger"><?php echo e($errors->first('guarantor_relation')); ?></div>
            <?php endif; ?>
        </div>
        <div class="<?php echo e($errors->has('guarantor_cnic') ? 'text-danger' : ''); ?> form-group col-md-3" id="guarantor_cnic_div">
            <?php echo Form::label('guarantor_cnic', 'CNIC', ['class' => 'control-label', 'style' => ""]); ?>

            <?php echo Form::number('guarantor_cnic', old('guarantor_cnic') ,['class' => 'form-control']); ?>

            <?php if($errors->has('guarantor_cnic')): ?>
                <div class="text-danger"><?php echo e($errors->first('guarantor_cnic')); ?></div>
            <?php endif; ?>
        </div>
        <div class="<?php echo e($errors->has('guarantor_address') ? 'text-danger' : ''); ?> form-group col-md-3" id="guarantor_address_div">
            <?php echo Form::label('guarantor_address', 'Address', ['class' => 'control-label', 'style' => ""]); ?>

            <?php echo Form::text('guarantor_address', old('guarantor_address') ,['class' => 'form-control']); ?>

            <?php if($errors->has('guarantor_address')): ?>
                <div class="text-danger"><?php echo e($errors->first('guarantor_address')); ?></div>
            <?php endif; ?>
        </div>
        <div class="<?php echo e($errors->has('cell_no') ? 'text-danger' : ''); ?> form-group col-md-3" id="guarantor_contact_div">
            <?php echo Form::label('guarantor_contact', 'Contact', ['class' => 'control-label', 'style' => ""]); ?>

            <?php echo Form::number('guarantor_contact', old('guarantor_contact') ,['class' => 'form-control']); ?>

            <?php if($errors->has('guarantor_contact')): ?>
                <div class="text-danger"><?php echo e($errors->first('guarantor_contact')); ?></div>
            <?php endif; ?>
        </div>

      </div>
    </div>
  </div>
</div>