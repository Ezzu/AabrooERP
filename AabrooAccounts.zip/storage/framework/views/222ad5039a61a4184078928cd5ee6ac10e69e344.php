        <?php echo e(csrf_field()); ?>

        <div class="<?php echo e($errors->has('branch_id') ? 'text-danger' : ''); ?> form-group col-md-3" id="branch_id_div">
            <?php echo Form::label('branch_id', 'Branch *', ['class' => 'control-label', 'style' => ""]); ?>

            <?php echo Form::select('branch_id', $Branches, old('branch_id'), ['class' => 'form-control select2']); ?>

            <?php if($errors->has('branch_id')): ?>
                <div class="text-danger"><?php echo e($errors->first('branch_id')); ?></div>
            <?php endif; ?>
        </div>
        <div class="<?php echo e($errors->has('department_id') ? 'text-danger' : ''); ?> form-group col-md-3" id="department_div">
            <?php echo Form::label('department_id', 'Department *', ['class' => 'control-label', 'style' => ""]); ?>

            <?php echo Form::select('department_id', $Departments, old('department_id'), ['class' => 'form-control select2']); ?>

            <?php if($errors->has('department_id')): ?>
                <div class="text-danger"><?php echo e($errors->first('department_id')); ?></div>
            <?php endif; ?>
        </div> 
        <div class="<?php echo e($errors->has('job_title_id') ? 'text-danger' : ''); ?> form-group col-md-3" id="job_title_div">
            <?php echo Form::label('job_title_id', 'Designation *', ['class' => 'control-label', 'style' => ""]); ?>

            <?php echo Form::select('job_title_id', $JobTitles, old('job_title_id'), ['class' => 'form-control select2']); ?>

            <?php if($errors->has('job_title_id')): ?>
                <div class="text-danger"><?php echo e($errors->first('job_title_id')); ?></div>
            <?php endif; ?>
        </div>
        <div class="<?php echo e($errors->has('image') ? 'text-danger' : ''); ?> form-group col-md-3" id="image_div">
            <img src="<?php echo e(isset($Employee) ? asset($Employee->image) : ''); ?>" style="border: 1px solid #aaa; width: 110px; height: 100px; margin-left: 50px;">
        </div>
        <div class="<?php echo e($errors->has('date_of_joining') ? 'text-danger' : ''); ?> form-group col-md-3" id="date_of_joining_div">
            <?php echo Form::label('date_of_joining', 'DOJ *', ['class' => 'control-label', 'style' => ""]); ?>

            <?php echo Form::text('date_of_joining', old('date_of_joining') ,['class' => 'form-control datetimepicker']); ?>

            <?php if($errors->has('date_of_joining')): ?>
                <div class="text-danger"><?php echo e($errors->first('date_of_joining')); ?></div>
            <?php endif; ?>
        </div>      
        <div class="<?php echo e($errors->has('name') ? 'text-danger' : ''); ?> form-group col-md-3" id="name_div">
            <?php echo Form::label('name', 'Name *', ['class' => 'control-label', 'style' => ""]); ?>

            <?php echo Form::text('name', old('user_id') ,['class' => 'form-control']); ?>

            <?php if($errors->has('name')): ?>
                <div class="text-danger"><?php echo e($errors->first('name')); ?></div>
            <?php endif; ?>
        </div>
        <div class="<?php echo e($errors->has('father_name') ? 'text-danger' : ''); ?> form-group col-md-3" id="father_name_div">
            <?php echo Form::label('father_name', 'Father Name *', ['class' => 'control-label', 'style' => ""]); ?>

            <?php echo Form::text('father_name', old('father_name') ,['class' => 'form-control']); ?>

            <?php if($errors->has('father_name')): ?>
                <div class="text-danger"><?php echo e($errors->first('father_name')); ?></div>
            <?php endif; ?>
        </div>
        <div class="<?php echo e($errors->has('gender') ? 'text-danger' : ''); ?> form-group col-md-3" id="gender_div">
            <?php echo Form::label('gender', 'Gender *', ['class' => 'control-label', 'style' => ""]); ?>

            <?php echo Form::select('gender', array('' => 'Select a Gender') + \Config::get('admin.gender_array'), old('gender'), ['class' => 'form-control select2']); ?>

            <?php if($errors->has('gender')): ?>
                <div class="text-danger"><?php echo e($errors->first('gender')); ?></div>
            <?php endif; ?>
        </div>
        <div class="<?php echo e($errors->has('cnic') ? 'text-danger' : ''); ?> form-group col-md-3" id="cnic_div">
            <?php echo Form::label('cnic', 'CNIC *', ['class' => 'control-label', 'style' => ""]); ?>

            <?php echo Form::number('cnic', old('cnic') ,['class' => 'form-control']); ?>

            <?php if($errors->has('cnic')): ?>
                <div class="text-danger"><?php echo e($errors->first('cnic')); ?></div>
            <?php endif; ?>
        </div>
        <div class="<?php echo e($errors->has('contact') ? 'text-danger' : ''); ?> form-group col-md-3" id="contact_div">
            <?php echo Form::label('contact', 'Contact *', ['class' => 'control-label', 'style' => ""]); ?>

            <?php echo Form::number('contact', old('contact') ,['class' => 'form-control']); ?>

            <?php if($errors->has('contact')): ?>
                <div class="text-danger"><?php echo e($errors->first('cnic')); ?></div>
            <?php endif; ?>
        </div>
        <div class="<?php echo e($errors->has('email') ? 'text-danger' : ''); ?> form-group col-md-3" id="email_div">
            <?php echo Form::label('email', 'Email *', ['class' => 'control-label', 'style' => ""]); ?>

            <?php echo Form::email('email', old('email') ,['class' => 'form-control']); ?>

            <?php if($errors->has('email')): ?>
                <div class="text-danger"><?php echo e($errors->first('email')); ?></div>
            <?php endif; ?>
        </div>
        <div class="<?php echo e($errors->has('permanent_address') ? 'text-danger' : ''); ?> form-group col-md-3" id="permanent_address_div">
            <?php echo Form::label('permanent_address', 'Permanent Address *', ['class' => 'control-label', 'style' => ""]); ?>

            <?php echo Form::text('permanent_address', old('permanent_address') ,['class' => 'form-control']); ?>

            <?php if($errors->has('permanent_address')): ?>
                <div class="text-danger"><?php echo e($errors->first('permanent_address')); ?></div>
            <?php endif; ?>
        </div>
        <div class="<?php echo e($errors->has('temporary_address') ? 'text-danger' : ''); ?> form-group col-md-3" id="temporary_address_div">
            <?php echo Form::label('temporary_address', 'Temporary Address *', ['class' => 'control-label', 'style' => ""]); ?>

            <?php echo Form::text('permanent_address', old('temporary_address') ,['class' => 'form-control']); ?>

            <?php if($errors->has('temporary_address')): ?>
                <div class="text-danger"><?php echo e($errors->first('temporary_address')); ?></div>
            <?php endif; ?>
        </div>
        <div class="<?php echo e($errors->has('city') ? 'text-danger' : ''); ?> form-group col-md-3" id="city_div">
            <?php echo Form::label('city', 'City *', ['class' => 'control-label', 'style' => ""]); ?>

            <?php echo Form::text('city', old('city') ,['class' => 'form-control']); ?>

            <?php if($errors->has('city')): ?>
                <div class="text-danger"><?php echo e($errors->first('city')); ?></div>
            <?php endif; ?>
        </div>
        <div class="clearfix"></div>
        <div class="panel-body pad table-responsive">
            <button onclick="FormControls.createLineItem();" style="margin-bottom: 5px;" class="btn pull-right btn-sm btn-flat btn-primary"><i class="fa fa-plus"></i>&nbsp;Add <u>R</u>ow</button>
                <table class="table table-bordered table-striped" id="qualifications-table">
                    <thead>
                        <tr>
                            <th>SrNo.</th>
                            <th>Degree Title</th>
                            <th>Passing Year</th>
                            <th>Division</th>
                            <th>Institution</th>
                            <th>Remove</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php  $counter=0 ?>
                        <?php if(count($Qualifications) ): ?>
                            <?php $__currentLoopData = $Qualifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php  $counter++ ?>
                                <tr id="line_item-<?php echo e($counter); ?>" >
                                    <td>
                                        <?php echo e($counter); ?>

                                    </td>
                                    <td>
                                        <div class="form-group  <?php if($errors->has('line_title')): ?> has-error <?php endif; ?>">
                                            <?php echo Form::text('line_items[title]['.$counter.']',  $val->title, ['id' => 'line_item-title_id-1','class' => 'form-control']); ?>

                                            <?php if($errors->has('line_title')): ?>
                                                <span class="help-block">
                                                    <?php echo e($errors->first('line_title')); ?>

                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="form-group  <?php if($errors->has('line_passing_year')): ?> has-error <?php endif; ?>">
                                            <?php echo Form::number('line_items[passing_year]['.$counter.']',  $val->passing_year, ['id' => 'line_item-passing_year_id-1','class' => 'form-control']); ?>

                                            <?php if($errors->has('line_passing_year')): ?>
                                                <span class="help-block">
                                                    <?php echo e($errors->first('line_passing_year')); ?>

                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="form-group  <?php if($errors->has('division')): ?> has-error <?php endif; ?>">
                                            <?php echo Form::select('line_items[division]['.$counter.']', array('' => 'Select a Division') + config('admin.division_array'), $val->division, ['id' => 'line_item-division_id-1','class' => 'form-control' ]); ?>

                                            <?php if($errors->has('line_division')): ?>
                                                <span class="help-block">
                                                    <?php echo e($errors->first('line_division')); ?>

                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="form-group  <?php if($errors->has('institution')): ?> has-error <?php endif; ?>">
                                            <?php echo Form::text('line_items[institution]['.$counter.']',  $val->institution, ['id' => 'line_item-institution_id-1','class' => 'form-control']); ?>

                                            <?php if($errors->has('line_institution')): ?>
                                                <span class="help-block">
                                                    <?php echo e($errors->first('line_institution')); ?>

                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td><button id="line_item-del_btn-<?php echo e($counter); ?>" onclick="FormControls.destroyLineItem('<?php echo e($counter); ?>');" type="button" class="btn btn-block btn-danger btn-sm"><i class="fa fa-trash"></i></button></td>
                                    <td><input type="hidden" id="q_id-<?php echo e($counter); ?>" value="<?php echo e($val->id); ?>"></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <input type="hidden" id="line_item-global_counter" value="<?php  echo ++$counter ?>"   />
                    </tbody>
                </table>
                
                    <table>
                        <tbody id="line_item-container" style='display:none'>
                            <tr class="line_item-container-<?php echo e($counter); ?>" id="line_item-######">
                                <td>
                                    <p id="line_item-no-######"><?php echo e($counter-1); ?></p>
                                </td>
                                <td >
                                    <div class="form-group" style="margin-bottom: 0px !important;">
                                        <div class="form-group" style="margin-bottom: 0px !important;">
                                        
                                            <?php echo Form::text('line_items[title][######]',  old('title'), ['id' => 'line_item-title_id-######','class' => 'form-control', 'required' => 'true']); ?>

                                            
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="form-group" style="margin-bottom: 0px !important;" >

                                        <?php echo Form::number('line_items[passing_year][######]',  old('passing_year'), ['id' => 'line_item-passing_year_id-######','class' => 'form-control', 'required' => 'true']); ?>


                                    </div>
                                </td>
                                <td>
                                    <div class="form-group" style="margin-bottom: 0px !important;" >

                                        <?php echo Form::select('line_items[division][######]', array('' => 'Select a Division') + Config::get('admin.division_array'), old('division'), ['id' => 'line_item-division_id-######','class' => 'form-control', 'required' => 'true']); ?>


                                    </div>
                                </td>
                                <td>
                                    <div class="form-group" style="margin-bottom: 0px !important;" >

                                        <?php echo Form::text('line_items[institution][######]',  old('institution'), ['id' => 'line_item-institution_id-######','class' => 'form-control', 'required' => 'true']); ?>


                                    </div>
                                </td>

                                <td><button id="line_item-del_btn-######" onclick="FormControls.destroyLineItem('######');" class="btn btn-block btn-danger btn-sm"><i class="fa fa-trash"></i></button></td>
                                <td><input type="hidden" id="q_id-######" value="not_applicable"></td>
                            </tr>
                        </tbody>
                    </table>
        </div>

        <div class="<?php echo e($errors->has('bank_id') ? 'text-danger' : ''); ?> form-group col-md-3" id="bank_id_div">
            <?php echo Form::label('bank_id', 'Bank *', ['class' => 'control-label', 'style' => ""]); ?>

            <?php echo Form::select('bank_id', $Banks, old('gender'), ['class' => 'form-control select2']); ?>

            <?php if($errors->has('bank_id')): ?>
                <div class="text-danger"><?php echo e($errors->first('bank_id')); ?></div>
            <?php endif; ?>
        </div>
        <div class="<?php echo e($errors->has('account_no') ? 'text-danger' : ''); ?> form-group col-md-3" id="account_no_div">
            <?php echo Form::label('account_no', 'Account No *', ['class' => 'control-label', 'style' => ""]); ?>

            <?php echo Form::text('account_no', old('account_no') ,['class' => 'form-control']); ?>

            <?php if($errors->has('account_no')): ?>
                <div class="text-danger"><?php echo e($errors->first('account_no')); ?></div>
            <?php endif; ?>
        </div>
        <div class="<?php echo e($errors->has('basic_salary') ? 'text-danger' : ''); ?> form-group col-md-3" id="basic_salary_div">
            <?php echo Form::label('basic_salary', 'Basic Salary *', ['class' => 'control-label', 'style' => ""]); ?>

            <?php echo Form::number('basic_salary', old('basic_salary') ,['class' => 'form-control']); ?>

            <?php if($errors->has('basic_salary')): ?>
                <div class="text-danger"><?php echo e($errors->first('basic_salary')); ?></div>
            <?php endif; ?>
        </div>
        <div class="<?php echo e($errors->has('medical_allowance') ? 'text-danger' : ''); ?> form-group col-md-3" id="medical_allowance_div">
            <?php echo Form::label('medical_allowance', 'Medical Allowance *', ['class' => 'control-label', 'style' => ""]); ?>

            <?php echo Form::number('medical_allowance', old('medical_allowance') ,['class' => 'form-control']); ?>

            <?php if($errors->has('medical_allowance')): ?>
                <div class="text-danger"><?php echo e($errors->first('medical_allowance')); ?></div>
            <?php endif; ?>
        </div>
        <div class="<?php echo e($errors->has('conveyance') ? 'text-danger' : ''); ?> form-group col-md-3" id="medical_allowance_div">
            <?php echo Form::label('conveyance', 'Conveyance *', ['class' => 'control-label', 'style' => ""]); ?>

            <?php echo Form::number('conveyance', old('conveyance') ,['class' => 'form-control']); ?>

            <?php if($errors->has('conveyance')): ?>
                <div class="text-danger"><?php echo e($errors->first('medical_allowance')); ?></div>
            <?php endif; ?>
        </div>
        <div class="<?php echo e($errors->has('image') ? 'text-danger' : ''); ?> form-group col-md-3" id="image_div">
            <?php echo Form::label('image', 'Choose an Image *', ['class' => 'control-label', 'style' => ""]); ?>

            <?php echo Form::file('image', old('image'), ['class' => 'form-control']); ?>

            <?php if($errors->has('image')): ?>
                <div class="text-danger"><?php echo e($errors->first('image')); ?></div>
            <?php endif; ?>
        </div>