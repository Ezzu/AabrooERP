<div class="panel-group">
  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" href="#collapse6">Medical Status</a>
      </h4>
    </div>
    <div id="collapse6" class="panel-collapse collapse">
      <div class="panel-body">
      
        <div class="<?php echo e($errors->has('mother_education') ? 'text-danger' : ''); ?> form-group col-md-3" id="eyesight_div">
            <?php echo Form::label('eyesight', 'Eyesight', ['class' => 'control-label', 'style' => ""]); ?>

            <?php echo Form::select('eyesight', array('' => 'Select a Status') + \Config::get('admin.normal_week_array'), old('mother_education'), ['class' => 'form-control select2']); ?>

            <?php if($errors->has('eyesight')): ?>
                <div class="text-danger"><?php echo e($errors->first('eyesight')); ?></div>
            <?php endif; ?>
        </div>    
        <div class="<?php echo e($errors->has('mother_education') ? 'text-danger' : ''); ?> form-group col-md-3" id="hearing_div">
            <?php echo Form::label('hearing', 'Hearing', ['class' => 'control-label', 'style' => ""]); ?>

            <?php echo Form::select('hearing', array('' => 'Select a Status') + \Config::get('admin.normal_week_array'), old('mother_education'), ['class' => 'form-control select2']); ?>

            <?php if($errors->has('hearing')): ?>
                <div class="text-danger"><?php echo e($errors->first('hearing')); ?></div>
            <?php endif; ?>
        </div> 
        <div class="<?php echo e($errors->has('mother_cnic') ? 'text-danger' : ''); ?> form-group col-md-3" id="weight_div">
            <?php echo Form::label('weight', 'Weight', ['class' => 'control-label', 'style' => ""]); ?>

            <?php echo Form::number('weight', old('weight'), ['class' => 'form-control']); ?>

            <?php if($errors->has('weight')): ?>
                <div class="text-danger"><?php echo e($errors->first('weight')); ?></div>
            <?php endif; ?>
        </div>
        <div class="<?php echo e($errors->has('mother_cnic') ? 'text-danger' : ''); ?> form-group col-md-3" id="height_div">
            <?php echo Form::label('height', 'Height', ['class' => 'control-label', 'style' => ""]); ?>

            <?php echo Form::number('height', old('height'), ['class' => 'form-control']); ?>

            <?php if($errors->has('height')): ?>
                <div class="text-danger"><?php echo e($errors->first('height')); ?></div>
            <?php endif; ?>
        </div>

      </div>
    </div>
  </div>
</div>