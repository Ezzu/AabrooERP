<?php echo e(csrf_field()); ?>


<div class="<?php echo e($errors->has('sponsership_date') ? 'text-danger' : ''); ?> form-group col-md-3" id="sponsership_date_div">
    <?php echo Form::label('sponsership_date', 'Sponsership Date *', ['class' => 'control-label', 'style' => ""]); ?>

    <?php echo Form::text('sponsership_date', old('sponsership_date') ,['class' => 'form-control datetimepicker']); ?>

    <?php if($errors->has('sponsership_date')): ?>
        <div class="text-danger"><?php echo e($errors->first('sponsership_date')); ?></div>
    <?php endif; ?>
</div>

<div class="<?php echo e($errors->has('donar_name') ? 'text-danger' : ''); ?> form-group col-md-3" id="donar_name_div">
    <?php echo Form::label('donar_name', 'Donar Name *', ['class' => 'control-label', 'style' => ""]); ?>

    <?php echo Form::text('donar_name', old('donar_name'), ['class' => 'form-control']); ?>

    <?php if($errors->has('donar_name')): ?>
        <div class="text-danger"><?php echo e($errors->first('donar_name')); ?></div>
    <?php endif; ?>
</div>

<div class="<?php echo e($errors->has('address') ? 'text-danger' : ''); ?> form-group col-md-6" id="address_div">
    <?php echo Form::label('address', 'Address *', ['class' => 'control-label', 'style' => ""]); ?>

    <?php echo Form::text('address', old('address'), ['class' => 'form-control']); ?>

    <?php if($errors->has('address')): ?>
        <div class="text-danger"><?php echo e($errors->first('address')); ?></div>
    <?php endif; ?>
</div>

<div class="<?php echo e($errors->has('cnic') ? 'text-danger' : ''); ?> form-group col-md-3" id="cnic_div">
    <?php echo Form::label('cnic', 'CNIC *', ['class' => 'control-label', 'style' => ""]); ?>

    <?php echo Form::text('cnic', old('cnic'), ['class' => 'form-control']); ?>

    <?php if($errors->has('cnic')): ?>
        <div class="text-danger"><?php echo e($errors->first('cnic')); ?></div>
    <?php endif; ?>
</div>

<div class="<?php echo e($errors->has('area_id') ? 'text-danger' : ''); ?> form-group col-md-3" id="area_id_div">
    <?php echo Form::label('area_id', 'Area *', ['class' => 'control-label', 'style' => ""]); ?>

    <?php echo Form::select('area_id', $Areas, old('area_id'), ['class' => 'form-control select2']); ?>

    <?php if($errors->has('area_id')): ?>
        <div class="text-danger"><?php echo e($errors->first('area_id')); ?></div>
    <?php endif; ?>
</div>

<div class="<?php echo e($errors->has('phone_no') ? 'text-danger' : ''); ?> form-group col-md-3" id="phone_no_div">
    <?php echo Form::label('phone_no', 'Phone No *', ['class' => 'control-label', 'style' => ""]); ?>

    <?php echo Form::text('phone_no', old('phone_no'), ['class' => 'form-control']); ?>

    <?php if($errors->has('phone_no')): ?>
        <div class="text-danger"><?php echo e($errors->first('phone_no')); ?></div>
    <?php endif; ?>
</div>

<div class="<?php echo e($errors->has('cell_no') ? 'text-danger' : ''); ?> form-group col-md-3" id="cell_no_div">
    <?php echo Form::label('cell_no', 'Cell No', ['class' => 'control-label', 'style' => ""]); ?>

    <?php echo Form::text('cell_no', old('cell_no'), ['class' => 'form-control']); ?>

    <?php if($errors->has('cell_no')): ?>
        <div class="text-danger"><?php echo e($errors->first('cell_no')); ?></div>
    <?php endif; ?>
</div>

<div class="<?php echo e($errors->has('email') ? 'text-danger' : ''); ?> form-group col-md-3" id="email_div">
    <?php echo Form::label('email', 'Email', ['class' => 'control-label', 'style' => ""]); ?>

    <?php echo Form::text('email', old('email'), ['class' => 'form-control']); ?>

    <?php if($errors->has('email')): ?>
        <div class="text-danger"><?php echo e($errors->first('email')); ?></div>
    <?php endif; ?>
</div>

<!-- <div class="<?php echo e($errors->has('sponser_count') ? 'text-danger' : ''); ?> form-group col-md-3" id="sponser_count_div">
    <?php echo Form::label('sponser_count', 'Sponser Count *', ['class' => 'control-label', 'style' => ""]); ?>

    <?php echo Form::number('sponser_count', '' ,['class' => 'form-control']); ?>

    <?php if($errors->has('sponser_count')): ?>
        <div class="text-danger"><?php echo e($errors->first('sponser_count')); ?></div>
    <?php endif; ?>
</div> -->

<div class="<?php echo e($errors->has('fee_per_child') ? 'text-danger' : ''); ?> form-group col-md-3" id="fee_per_child_div">
    <?php echo Form::label('fee_per_child', 'Fee Per Child *', ['class' => 'control-label', 'style' => ""]); ?>

    <?php echo Form::number('fee_per_child', old('fee_per_child'), ['class' => 'form-control']); ?>

    <?php if($errors->has('fee_per_child')): ?>
        <div class="text-danger"><?php echo e($errors->first('fee_per_child')); ?></div>
    <?php endif; ?>
</div>

<div class="<?php echo e($errors->has('payment_type_id') ? 'text-danger' : ''); ?> form-group col-md-3" id="payment_type_id_div">
    <?php echo Form::label('payment_type_id', 'Payment Method *', ['class' => 'control-label', 'style' => ""]); ?>

    <?php echo Form::select('payment_type_id', $PaymentTypes, old('payment_type_id'), ['class' => 'form-control select2']); ?>

    <?php if($errors->has('payment_type_id')): ?>
        <div class="text-danger"><?php echo e($errors->first('payment_type_id')); ?></div>
    <?php endif; ?>
</div>