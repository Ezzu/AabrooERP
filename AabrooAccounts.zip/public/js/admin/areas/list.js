var FormControls = function(){

}();

$(document).ready(function(){
    alert('OK');
});