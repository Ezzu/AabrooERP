<?php

namespace App\Models\Admin;
use Illuminate\Database\Eloquent\SoftDeletes;


use Illuminate\Database\Eloquent\Model;

class WorkingDaysModel extends Model
{
    use SoftDeletes;

    protected $fillable = ['name', 'status', 'created_by', 'updated_by', 'deleted_by', 'deleted_at'];

    protected $table = "working_days";

    public function swdonars(){
        return $this->hasMany('App\Models\Admin\SWDonarsModel', 'day_id');
    }
    
}
